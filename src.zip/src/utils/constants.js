// API config для доступа
export const apiConfig = {
  url: 'https://mesto.nomoreparties.co/v1/cohort-71',
  headers:{
    'Content-Type': "application/json",
    authorization: 'a2b723e3-a104-4268-8462-81c1140190b0'
  }
}

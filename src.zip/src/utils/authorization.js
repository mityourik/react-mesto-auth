export const BASE_URL = "https://auth.nomoreparties.co";

async function checkResponse(res) {
  if (res.ok) {
    return res.json();
  }
  const errorMessage = await res.text();
  throw new Error(`Ошибка: ${res.status} - ${errorMessage}`);
}

export const register = async (password, email) => {
  const response = await fetch(`${BASE_URL}/signup`, {
    method: 'POST',
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ password, email })
  });
  return checkResponse(response);
};

export const authorize = async (password, email) => {
  const response = await fetch(`${BASE_URL}/signin`, {
    method: 'POST',
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ password, email })
  });
  return checkResponse(response);
};

export const getContent = async (token) => {
  const response = await fetch(`${BASE_URL}/users/me`, {
    method: 'GET',
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    }
  });
  return checkResponse(response);
};